import type { WorkState } from './work-contract.ts';
import type { IntelligenceAction, InteractionRecord } from './interaction-contract.ts';
import { getAttention, suggestNextFocus } from './intelligence.ts';

export function applyIntelligenceAction(current: WorkState, action: IntelligenceAction, now: Date, makeId = () => crypto.randomUUID()): WorkState {
  const next = structuredClone(current);
  if (current.command.interactions.some(r => r.requestId === action.requestId)) throw new Error('Diese App-Anfrage wurde bereits dokumentiert. Den aktuellen Verlauf prüfen.');
  if (next.command.interactions.length >= 120) throw new Error('120 dokumentierte Interaktionen erreicht. Exportiere den Stand; der Verlauf wird nicht still gelöscht.');
  let record: InteractionRecord;
  if (action.action === 'focus-follow') {
    const suggestion = suggestNextFocus(action.missionId, current, now.getTime());
    if (!suggestion || suggestion.id !== action.suggestionId) throw new Error('Diese Fokus-Empfehlung ist nicht mehr aktuell.');
    const mission = next.command.missions.find(m => m.id === action.missionId)!;
    if (suggestion.type === 'mission-stage' && suggestion.nextStage) mission.stage = suggestion.nextStage;
    if (suggestion.type === 'task-start' && suggestion.taskId) next.tasks.find(t => t.id === suggestion.taskId)!.status = 'In Arbeit';
    record = { id: makeId(), requestId: action.requestId, requestFingerprint: suggestion.id, at: now.toISOString(), kind: 'focus-followed', missionId: mission.id, sourceId: suggestion.id, fingerprint: '', reason: suggestion.title.slice(0, 500), taskId: suggestion.taskId || null };
  } else {
    const risk = getAttention(current, now.getTime()).find(a => a.id === action.sourceId && a.fingerprint === action.fingerprint);
    if (!risk || risk.accepted) throw new Error('Diese Risikobedingung ist nicht mehr offen oder wurde bereits akzeptiert.');
    let taskId: string | null = null;
    if (action.action === 'risk-plan') {
      if (risk.plannedTaskId) throw new Error('Für diese Bedingung gibt es bereits eine Prüfaufgabe.');
      if (next.tasks.length >= 60) throw new Error('Aufgabenlimit erreicht. Bestehende Prüfaufgaben verwenden.');
      const mission = next.command.missions.find(m => m.id === risk.missionId);
      if (mission && mission.taskIds.length >= 20) throw new Error('Die Mission hat bereits 20 Aufgaben.');
      taskId = makeId();
      next.tasks.push({ id: taskId, title: ('Risiko prüfen: ' + risk.title).slice(0, 150), category: 'Funktion', priority: 'P0', owner: mission?.reviewer || 'junior', status: 'Offen', acceptance: ('Bedingung nachweisbar beheben oder begründete Entscheidung dokumentieren: ' + risk.reason + '. ' + action.reason).slice(0, 1500), evidence: '', reviewed: false, dependencies: [], archived: false });
      if (mission) {
        if (mission.stage === 'Approved') { mission.stage = 'Review'; mission.reviewed = false; }
        mission.taskIds.push(taskId);
      }
    }
    record = { id: makeId(), requestId: action.requestId, requestFingerprint: action.fingerprint, at: now.toISOString(), kind: action.action === 'risk-accept' ? 'risk-accepted' : 'risk-task-created', missionId: risk.missionId, sourceId: risk.id, fingerprint: risk.fingerprint, reason: action.reason, taskId };
  }
  next.command.interactions.push(record);
  return next;
}
