import type { WorkState } from './work-contract.ts';
import { stageNames, stageTransitions, type AppEvent } from './command-contract.ts';
import { calculateNeuroScore } from './neuro.ts';
import { getAttention } from './intelligence.ts';

const equal = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

/** Own app records, not proof of remote execution. Validate the whole result after every edit. */
export function workReferenceErrors(next: WorkState, knownSources: readonly string[]): string[] {
  const tasks = new Map(next.tasks.map(t => [t.id, t]));
  const rooms = new Set(next.rooms.map(r => r.id));
  const sources = new Set(knownSources);
  const errors: string[] = [];
  const entities=[...next.notes,...next.rooms,...next.tasks,...next.command.missions,...next.command.approvals,...next.command.interactions];
  if(new Set(entities.map(e=>e.id)).size!==entities.length)errors.push('Eigene Entitäten benötigen über alle Datenbereiche hinweg eindeutige IDs.');
  if (next.settings.neuro.focusMissionId && !next.command.missions.some(m => m.id === next.settings.neuro.focusMissionId)) errors.push('Die ausgewählte Fokusmission fehlt.');
  for (const r of next.rooms) if (r.sources.some(id => !sources.has(id))) errors.push(`${r.title}: Eine Quelle des Missionraums fehlt.`);
  for (const m of next.command.missions) {
    if (m.taskIds.some(id => !tasks.has(id))) errors.push(`${m.title}: Eine referenzierte Aufgabe fehlt.`);
    if (m.roomId && !rooms.has(m.roomId)) errors.push(`${m.title}: Der referenzierte Missionraum fehlt.`);
    if (m.sourceIds.some(id => !sources.has(id))) errors.push(`${m.title}: Eine ausgewählte Quelle fehlt im Quellenbestand.`);
    if (['Approved', 'Done'].includes(m.stage) && m.taskIds.some(id => tasks.get(id)?.status !== 'Erledigt')) {
      errors.push(`${m.title}: Zugeordnete Aufgaben müssen vor der Abnahme abgeschlossen sein.`);
    }
  }
  return errors;
}

export function workChangeErrors(current: WorkState, next: WorkState, now: Date, knownSources: readonly string[], internalAction = false): string[] {
  const errors = workReferenceErrors(next, knownSources);
  const oldTasks = new Map(current.tasks.map(t => [t.id, t]));
  const newTasks = new Map(next.tasks.map(t => [t.id, t]));
  if (!internalAction && !equal(current.command.interactions, next.command.interactions)) errors.push('Interaktionen werden ausschließlich über geprüfte App-Aktionen dokumentiert.');
  if (!equal(current.command.events, next.command.events)) errors.push('Der App-Ereignisverlauf wird vom Server geführt und kann nicht ersetzt werden.');
  const missions = new Map(current.command.missions.map(m => [m.id, m]));
  for (const old of current.command.missions) {
    if (!next.command.missions.some(m => m.id === old.id)) errors.push('Missionen bleiben erhalten. Verwende stattdessen das Archiv.');
  }
  for (const m of next.command.missions) {
    const old = missions.get(m.id);
    if (!old && m.stage !== 'Created') errors.push('Eine neue Mission beginnt mit Erstellt.');
    if (old && m.createdAt !== old.createdAt) errors.push('Der Erstellungszeitpunkt einer Mission bleibt unverändert.');
    if (old && m.stage !== old.stage && !stageTransitions[old.stage].includes(m.stage)) errors.push(`${m.title}: Dieser Phasenwechsel ist nicht vorgesehen.`);
    if (old && ['Approved', 'Done'].includes(old.stage) && ['Approved', 'Done'].includes(m.stage)) {
      const { stage: _oldStage, archived: _oldArchived, neuro_profile: _oldProfile, ...oldContent } = old;
      const { stage: _stage, archived: _archived, neuro_profile: _profile, ...newContent } = m;
      if (!equal(oldContent, newContent)) errors.push('Vor einer inhaltlichen Änderung muss die Mission zurück in die Gegenprüfung.');
      const protectedTasks = new Set<string>();
      const collect = (id: string) => {
        if (protectedTasks.has(id)) return;
        protectedTasks.add(id);
        oldTasks.get(id)?.dependencies.forEach(collect);
      };
      old.taskIds.forEach(collect);
      for (const id of protectedTasks) {
        const previous = oldTasks.get(id), changed = newTasks.get(id);
        const acceptance = (t: WorkState['tasks'][number] | undefined) => t && ({ title: t.title, owner: t.owner, status: t.status, acceptance: t.acceptance, evidence: t.evidence, reviewed: t.reviewed, dependencies: t.dependencies });
        if (!equal(acceptance(previous), acceptance(changed))) errors.push('Eine abnahmerelevante Aufgabe wurde geändert. Zugehörige Mission zuerst zurück in die Gegenprüfung setzen.');
      }
    }
  }
  const approvals = new Map(current.command.approvals.map(a => [a.id, a]));
  for (const old of current.command.approvals) {
    if (!next.command.approvals.some(a => a.id === old.id)) errors.push('Freigabeentscheidungen und ihre Anfragen bleiben im Verlauf erhalten.');
  }
  for (const a of next.command.approvals) {
    const old = approvals.get(a.id);
    if (!old && a.status !== 'pending') errors.push('Eine neue Freigabekarte beginnt als offene Anfrage.');
    if (old && a.createdAt !== old.createdAt) errors.push('Der Erstellungszeitpunkt einer Freigabe bleibt unverändert.');
    if (old && old.status !== 'pending' && !equal(old, a)) errors.push('Eine entschiedene Karte ist unveränderlich. Erstelle eine neue Anfrage.');
    if (old && old.status === 'pending' && a.status !== 'pending') {
      const { status: _oldStatus, decidedAt: _oldAt, decisionNote: _oldNote, ...oldContent } = old;
      const { status: _status, decidedAt: _at, decisionNote: _note, ...newContent } = a;
      if (!equal(oldContent, newContent)) errors.push('Inhalt ändern und entscheiden sind getrennte Schritte. Speichere zuerst die Anfrage.');
      if (a.status === 'approved' && Date.parse(a.expiresAt) <= now.getTime()) errors.push('Die Anfrage ist abgelaufen. Erstelle eine neue Karte.');
    }
    if ((!old || !equal(old, a)) && a.status === 'pending' && Date.parse(a.expiresAt) <= now.getTime()) errors.push('Eine neue oder geänderte Anfrage braucht ein zukünftiges Ablaufdatum.');
  }
  return [...new Set(errors)];
}

/** Decisions use server time; actor is the authenticated owner of this work row. */
export function withCanonicalDecisionTimes(current: WorkState, next: WorkState, now: Date): WorkState {
  return {
    ...next,
    command: {
      ...next.command,
      approvals: next.command.approvals.map(a => {
        const old = current.command.approvals.find(x => x.id === a.id);
        return old?.status === 'pending' && a.status !== 'pending' ? { ...a, decidedAt: now.toISOString() } : a;
      }),
    },
  };
}

export function withAppEvents(current: WorkState, next: WorkState, now: Date, makeId = () => crypto.randomUUID()): WorkState {
  const pending: Omit<AppEvent, 'id' | 'sequence' | 'at' | 'origin' | 'neuro_profile'>[] = [];
  for (const m of next.command.missions) {
    const old = current.command.missions.find(x => x.id === m.id);
    if (!old) pending.push({ kind: 'mission-created', entityId: m.id, neuro_context: { stage: m.stage, priority: m.priority }, title: `Mission erstellt: ${m.title}` });
    else if (old.stage !== m.stage) pending.push({ kind: 'mission-stage', entityId: m.id, neuro_context: { stage: m.stage, priority: m.priority }, title: `${m.title}: ${stageNames[old.stage]} → ${stageNames[m.stage]}` });
    else if (!equal(old, m)) pending.push({ kind: 'mission-updated', entityId: m.id, neuro_context: { stage: m.stage, priority: m.priority }, title: `Mission aktualisiert: ${m.title}` });
  }
  for (const a of next.command.approvals) {
    const old = current.command.approvals.find(x => x.id === a.id);
    if (!old) pending.push({ kind: 'approval-created', entityId: a.id, neuro_context: { risk: a.risk }, title: `Freigabe angefragt: ${a.action}` });
    else if (old.status !== a.status) pending.push({ kind: 'approval-decided', entityId: a.id, neuro_context: { risk: a.risk, decision: a.status as 'approved' | 'denied' }, title: `${a.status === 'approved' ? 'Entscheidung dokumentiert' : 'Abgelehnt'}: ${a.action}` });
    else if (!equal(old, a)) pending.push({ kind: 'approval-updated', entityId: a.id, neuro_context: { risk: a.risk }, title: `Freigabeentwurf geändert: ${a.action}` });
  }
  for (const t of next.tasks) {
    const old = current.tasks.find(x => x.id === t.id);
    if (!old || !equal(old, t)) pending.push({ kind: 'task-updated', entityId: t.id, neuro_context: { taskStatus: t.status, priority: t.priority }, title: `Aufgabe ${old ? 'aktualisiert' : 'angelegt'}: ${t.title} · ${t.status}` });
  }
  for (const r of next.command.interactions) if (!current.command.interactions.some(old => old.id === r.id)) pending.push({ kind: r.kind, entityId: r.missionId, neuro_context: {}, title: `${r.kind === 'risk-accepted' ? 'Risiko akzeptiert; Bedingung bleibt bestehen' : r.kind === 'risk-task-created' ? 'Prüfaufgabe zur Risikoauflösung angelegt' : 'Fokus-Empfehlung ausgeführt'}: ${r.reason}`.slice(0, 350) });
  const labels = { checks: 'Planmarker', notes: 'Arbeitsnotizen', settings: 'Dashboard und Chatstandards', profiles: 'Arbeitsprofile', rooms: 'Missionräume', learning: 'Lernfortschritt' } as const;
  for (const key of Object.keys(labels) as (keyof typeof labels)[]) {
    if (!equal(current[key], next[key])) pending.push({ kind: 'workspace-updated', entityId: null, neuro_context: {}, title: `${labels[key]} aktualisiert` });
  }
  let sequence = current.command.events.at(-1)?.sequence || 0;
  const events: AppEvent[] = pending.map(e => ({ ...e, id: makeId(), sequence: ++sequence, at: now.toISOString(), origin: 'app', neuro_profile: calculateNeuroScore({ kind: e.kind, ...e.neuro_context }) }));
  const result = { ...next, command: { ...next.command, events: [...current.command.events, ...events].slice(-200) } };
  for (const record of result.command.interactions) {
    if (record.kind === 'risk-task-created' && !current.command.interactions.some(r => r.id === record.id)) {
      const risk = getAttention(result, now.getTime()).find(a => a.id === record.sourceId);
      if (risk) record.fingerprint = risk.fingerprint;
    }
  }
  return result;
}
